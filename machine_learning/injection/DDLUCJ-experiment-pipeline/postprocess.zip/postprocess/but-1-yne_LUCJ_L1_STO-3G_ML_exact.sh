#!/bin/bash
#SBATCH --time=0-24:00:00
#SBATCH -J but-1-yne_LUCJ_L1_STO-3G_ML_exact
#SBATCH --account=rrg-jacobsen-ab
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --mem-per-cpu=2GB
#SBATCH --error=job.e%J
#SBATCH --output=job.o%j


set -e

echo 'About to run python file'
module load python/3.10
module load StdEnv/2023
module load openmpi
module load symengine rust
module load hdf5
module load openblas

echo "TEMP DIR: $SLURM_TMPDIR"
virtualenv --no-download $SLURM_TMPDIR/env
source $SLURM_TMPDIR/env/bin/activate
pip install --no-index --upgrade pip
pip install /scratch/gjones/wheels/fulqrum*.whl
pip install -e /home/gjones/scratch/distributed_LUCJ/
pip install openfermion

export LD_LIBRARY_PATH=$EBROOTOPENBLAS/lib:$LD_LIBRARY_PATH
export OMP_NUM_THREADS=32
export OPENBLAS_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=$SLURM_CPUS_PER_TASK
export NUMEXPR_NUM_THREADS=$SLURM_CPUS_PER_TASK

echo "Running in directory: $(pwd)"
echo "but-1-yne_LUCJ_L1_STO-3G_ML_exact"
python "but-1-yne_LUCJ_L1_STO-3G_ML_exact.py"
echo "File run"    
